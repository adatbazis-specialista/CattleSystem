USE [master]
GO
/****** Object:  Database [HunlandCattleSystem]    Script Date: 2021.08.21 17:26:27 ******/
CREATE DATABASE [HunlandCattleSystem]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'HunlandCattleSystem', FILENAME = N'e:\Traning360\Adatbázis specialista\Adatbázisok\HunlandCattleSystem.mdf' , SIZE = 112640KB , MAXSIZE = UNLIMITED, FILEGROWTH = 10%), 
 FILEGROUP [TrainingData] 
( NAME = N'HunlandCattleSystemDataFile', FILENAME = N'e:\Traning360\Adatbázis specialista\Adatbázisok\HunlandCattleSystemDataFile.ndf' , SIZE = 112640KB , MAXSIZE = UNLIMITED, FILEGROWTH = 10%)
 LOG ON 
( NAME = N'HunlandCattleSystem_log', FILENAME = N'e:\Traning360\Adatbázis specialista\Adatbázisok\HunlandCattleSystemDataFile_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [HunlandCattleSystem] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [HunlandCattleSystem].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [HunlandCattleSystem] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET ARITHABORT OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [HunlandCattleSystem] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [HunlandCattleSystem] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET  ENABLE_BROKER 
GO
ALTER DATABASE [HunlandCattleSystem] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [HunlandCattleSystem] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET RECOVERY FULL 
GO
ALTER DATABASE [HunlandCattleSystem] SET  MULTI_USER 
GO
ALTER DATABASE [HunlandCattleSystem] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [HunlandCattleSystem] SET DB_CHAINING OFF 
GO
ALTER DATABASE [HunlandCattleSystem] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [HunlandCattleSystem] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [HunlandCattleSystem] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [HunlandCattleSystem] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
EXEC sys.sp_db_vardecimal_storage_format N'HunlandCattleSystem', N'ON'
GO
ALTER DATABASE [HunlandCattleSystem] SET QUERY_STORE = OFF
GO
USE [HunlandCattleSystem]
GO
/****** Object:  ApplicationRole [TabletApp]    Script Date: 2021.08.21 17:26:27 ******/
/* To avoid disclosure of passwords, the password is generated in script. */
declare @idx as int
declare @randomPwd as nvarchar(64)
declare @rnd as float
select @idx = 0
select @randomPwd = N''
select @rnd = rand((@@CPU_BUSY % 100) + ((@@IDLE % 100) * 100) + 
       (DATEPART(ss, GETDATE()) * 10000) + ((cast(DATEPART(ms, GETDATE()) as int) % 100) * 1000000))
while @idx < 64
begin
   select @randomPwd = @randomPwd + char((cast((@rnd * 83) as int) + 43))
   select @idx = @idx + 1
select @rnd = rand()
end
declare @statement nvarchar(4000)
select @statement = N'CREATE APPLICATION ROLE [TabletApp] WITH DEFAULT_SCHEMA = [dbo], ' + N'PASSWORD = N' + QUOTENAME(@randomPwd,'''')
EXEC dbo.sp_executesql @statement
GO
/****** Object:  ApplicationRole [RRApp]    Script Date: 2021.08.21 17:26:27 ******/
/* To avoid disclosure of passwords, the password is generated in script. */
declare @idx as int
declare @randomPwd as nvarchar(64)
declare @rnd as float
select @idx = 0
select @randomPwd = N''
select @rnd = rand((@@CPU_BUSY % 100) + ((@@IDLE % 100) * 100) + 
       (DATEPART(ss, GETDATE()) * 10000) + ((cast(DATEPART(ms, GETDATE()) as int) % 100) * 1000000))
while @idx < 64
begin
   select @randomPwd = @randomPwd + char((cast((@rnd * 83) as int) + 43))
   select @idx = @idx + 1
select @rnd = rand()
end
declare @statement nvarchar(4000)
select @statement = N'CREATE APPLICATION ROLE [RRApp] WITH DEFAULT_SCHEMA = [dbo], ' + N'PASSWORD = N' + QUOTENAME(@randomPwd,'''')
EXEC dbo.sp_executesql @statement
GO
/****** Object:  DatabaseRole [HunStock]    Script Date: 2021.08.21 17:26:27 ******/
CREATE ROLE [HunStock]
GO
/****** Object:  DatabaseRole [HunMember]    Script Date: 2021.08.21 17:26:27 ******/
CREATE ROLE [HunMember]
GO
/****** Object:  DatabaseRole [Hunadmin]    Script Date: 2021.08.21 17:26:27 ******/
CREATE ROLE [Hunadmin]
GO
/****** Object:  Table [dbo].[CattleDetailAdditional]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CattleDetailAdditional](
	[DetailEventID] [int] IDENTITY(1,1) NOT NULL,
	[CattleDetailID] [int] NOT NULL,
	[CurrentHoldingCodeID] [int] NOT NULL,
	[StableNumber] [smallint] NULL,
	[ArrivalWeight] [smallint] NOT NULL,
	[RemovalWeight] [smallint] NULL,
	[Weighing] [smallint] NULL,
	[ArrivalClassID] [tinyint] NOT NULL,
	[RemovalClassID] [tinyint] NULL,
	[DateOfArrival] [smalldatetime] NOT NULL,
	[DateOfRemoval] [smalldatetime] NULL,
	[ArrivalTransferID] [tinyint] NOT NULL,
	[RemovalTransferID] [tinyint] NULL,
	[ArrivalProductionTargetID] [tinyint] NOT NULL,
	[RemovallProductionTargetID] [tinyint] NULL,
	[ArrivalLicensePlateTruck] [varchar](10) NOT NULL,
	[ArrivalLicensePlateTrailer] [varchar](10) NOT NULL,
	[RemovalLicensePlateTruck] [varchar](10) NULL,
	[RemovalLicensePlateTrailer] [varchar](10) NULL,
	[PrchasePrice] [money] NULL,
	[SellingPrice] [money] NULL,
	[TreatmentID] [int] NULL,
 CONSTRAINT [PK_CattleDetailAdditional_DetailEventID] PRIMARY KEY CLUSTERED 
(
	[DetailEventID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CattleDetailBasic]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CattleDetailBasic](
	[CattleDetailID] [int] IDENTITY(1,1) NOT NULL,
	[WorkNumber] [varchar](6) NOT NULL,
	[CattleCountryCodeID] [int] NOT NULL,
	[IdentificationNumber] [varchar](25) NULL,
	[ExportNumber] [tinyint] NULL,
	[SexID] [tinyint] NOT NULL,
	[BreedID] [tinyint] NOT NULL,
	[ColourID] [tinyint] NOT NULL,
	[DateOfBirth] [smalldatetime] NOT NULL,
	[DamsCountryCodeID] [int] NOT NULL,
	[DamsNumber] [varchar](25) NOT NULL,
	[HoldingCountryCodeID] [int] NOT NULL,
	[HoldingCodeID] [int] NOT NULL,
 CONSTRAINT [PK_CattleDetailBasic_CattleDetailID] PRIMARY KEY CLUSTERED 
(
	[CattleDetailID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DictBreed]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DictBreed](
	[BreedID] [tinyint] IDENTITY(1,1) NOT NULL,
	[BreedCode] [varchar](3) NOT NULL,
	[BreedE] [varchar](80) NOT NULL,
	[BreedH] [varchar](80) NOT NULL,
	[BreedActive] [bit] NOT NULL,
 CONSTRAINT [PK_DictBreed_BreedID] PRIMARY KEY CLUSTERED 
(
	[BreedID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DictClass]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DictClass](
	[ClassID] [tinyint] IDENTITY(1,1) NOT NULL,
	[ClassCode] [varchar](5) NOT NULL,
	[ClassDetailE] [varchar](30) NOT NULL,
	[ClassDetailH] [varchar](30) NOT NULL,
	[ClassActive] [bit] NOT NULL,
 CONSTRAINT [PK_DictClass_ClassID] PRIMARY KEY CLUSTERED 
(
	[ClassID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DictColour]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DictColour](
	[ColourID] [tinyint] IDENTITY(1,1) NOT NULL,
	[ColourCodeE] [varchar](3) NULL,
	[ColourCodeH] [varchar](3) NOT NULL,
	[ColourDetailH] [varchar](30) NOT NULL,
	[ColourDetailE] [varchar](30) NULL,
	[ColourActive] [bit] NOT NULL,
 CONSTRAINT [PK_DictColour_ColourID] PRIMARY KEY CLUSTERED 
(
	[ColourID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DictCountryCode]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DictCountryCode](
	[CountryCodeID] [int] IDENTITY(1,1) NOT NULL,
	[CountryCodeDetailE] [varchar](50) NOT NULL,
	[CountryCodeDetailH] [varchar](50) NOT NULL,
	[CountryCodeISO2] [varchar](2) NOT NULL,
	[CountryCodeISO3] [varchar](3) NOT NULL,
	[CountryCodeNumeric] [smallint] NULL,
 CONSTRAINT [PK_DictCountryCode_CountryCodeID] PRIMARY KEY CLUSTERED 
(
	[CountryCodeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DictProductionTarget]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DictProductionTarget](
	[ProductionTargetID] [tinyint] IDENTITY(1,1) NOT NULL,
	[ProductionTargetCodeE] [varchar](2) NOT NULL,
	[ProductionTargetCode] [varchar](2) NOT NULL,
	[ProductionTargetDetailE] [varchar](30) NOT NULL,
	[ProductionTargetDetailH] [varchar](30) NOT NULL,
 CONSTRAINT [PK_DictProductionTarget_ProductionTargetID] PRIMARY KEY CLUSTERED 
(
	[ProductionTargetID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DictSex]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DictSex](
	[SexID] [tinyint] IDENTITY(1,1) NOT NULL,
	[SexOrgCodeE] [varchar](2) NOT NULL,
	[SexOrgCodeH] [varchar](2) NOT NULL,
	[SexE] [varchar](25) NOT NULL,
	[SexH] [varchar](25) NOT NULL,
 CONSTRAINT [PK_DictSex_SexID] PRIMARY KEY CLUSTERED 
(
	[SexID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DictTransfer]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DictTransfer](
	[TransferID] [tinyint] IDENTITY(1,1) NOT NULL,
	[TransferCode] [varchar](2) NOT NULL,
	[TransferDetailE] [varchar](30) NOT NULL,
	[TransferDetailH] [varchar](30) NOT NULL,
	[TransferActive] [bit] NOT NULL,
 CONSTRAINT [PK_DictTransfer_TransferID] PRIMARY KEY CLUSTERED 
(
	[TransferID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DictUser]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DictUser](
	[UserID] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](20) NOT NULL,
	[MiddleName] [varchar](20) NULL,
	[LastName] [varchar](20) NOT NULL,
	[UserName] [varchar](20) NOT NULL,
	[UserPassword] [varchar](50) NOT NULL,
	[EmailAddress] [varchar](50) NOT NULL,
	[AdminRole] [bit] NOT NULL,
	[MedicineRole] [bit] NOT NULL,
	[TreatmentRole] [bit] NOT NULL,
	[CatlleRole] [bit] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CurrentHoldingCodeID] [int] NULL,
 CONSTRAINT [PK_DictUser_UserID] PRIMARY KEY CLUSTERED 
(
	[UserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FarmDetail]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FarmDetail](
	[HoldingCodeID] [int] IDENTITY(1,1) NOT NULL,
	[CountryCodeID] [int] NOT NULL,
	[FarmDetailName] [varchar](50) NOT NULL,
	[FarmDetailAddress] [varchar](50) NOT NULL,
	[FarmDetailTown] [varchar](30) NOT NULL,
	[FarmDetailPhone] [varchar](50) NULL,
	[FarmDetailHoldingCode] [varchar](30) NULL,
	[FarmDetailActive] [bit] NOT NULL,
	[FarmDetailIsPartner] [bit] NOT NULL,
 CONSTRAINT [PK_FarmDetail_HoldingCodeID] PRIMARY KEY CLUSTERED 
(
	[HoldingCodeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Medicine]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Medicine](
	[MedicineID] [smallint] IDENTITY(1,1) NOT NULL,
	[MedicineName] [varchar](50) NULL,
	[MedicineQuantityUnit] [smallint] NOT NULL,
	[MedicineArticleNumber] [varchar](25) NOT NULL,
	[MedicineCodeNumber] [varchar](15) NULL,
 CONSTRAINT [PK_Medicine_MedicineID] PRIMARY KEY CLUSTERED 
(
	[MedicineID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Treatment]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Treatment](
	[TreatmentID] [int] IDENTITY(1,1) NOT NULL,
	[CatlleDetailID] [int] NOT NULL,
	[HoldingCode] [varchar](30) NOT NULL,
	[DateOfTreatment] [smalldatetime] NOT NULL,
	[StableNumber] [smallint] NULL,
	[DiagnosisName] [varchar](50) NULL,
	[MedicineID] [smallint] NULL,
	[Quantity] [tinyint] NOT NULL,
 CONSTRAINT [PK_Treatment_TreatmentID] PRIMARY KEY CLUSTERED 
(
	[TreatmentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserLoginHistory]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserLoginHistory](
	[UserLoginHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NOT NULL,
	[IPaddress] [varchar](50) NOT NULL,
	[SystemVersion] [varchar](50) NOT NULL,
	[MacAddress] [varchar](50) NOT NULL,
	[LoginDate] [datetime2](7) NOT NULL,
	[LogoutDate] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_UserLoginHistory_UserLoginHistoryID] PRIMARY KEY CLUSTERED 
(
	[UserLoginHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CattleDetailAdditional]  WITH CHECK ADD  CONSTRAINT [FK_CattleDetailBasic_CattleDetailID] FOREIGN KEY([CattleDetailID])
REFERENCES [dbo].[CattleDetailBasic] ([CattleDetailID])
GO
ALTER TABLE [dbo].[CattleDetailAdditional] CHECK CONSTRAINT [FK_CattleDetailBasic_CattleDetailID]
GO
ALTER TABLE [dbo].[CattleDetailAdditional]  WITH CHECK ADD  CONSTRAINT [FK_Class_ArrivalClassID] FOREIGN KEY([ArrivalClassID])
REFERENCES [dbo].[DictClass] ([ClassID])
GO
ALTER TABLE [dbo].[CattleDetailAdditional] CHECK CONSTRAINT [FK_Class_ArrivalClassID]
GO
ALTER TABLE [dbo].[CattleDetailAdditional]  WITH CHECK ADD  CONSTRAINT [FK_Class_RemovalClassID] FOREIGN KEY([RemovalClassID])
REFERENCES [dbo].[DictClass] ([ClassID])
GO
ALTER TABLE [dbo].[CattleDetailAdditional] CHECK CONSTRAINT [FK_Class_RemovalClassID]
GO
ALTER TABLE [dbo].[CattleDetailAdditional]  WITH CHECK ADD  CONSTRAINT [FK_FarmDetail_HoldingCodeID] FOREIGN KEY([CurrentHoldingCodeID])
REFERENCES [dbo].[FarmDetail] ([HoldingCodeID])
GO
ALTER TABLE [dbo].[CattleDetailAdditional] CHECK CONSTRAINT [FK_FarmDetail_HoldingCodeID]
GO
ALTER TABLE [dbo].[CattleDetailAdditional]  WITH CHECK ADD  CONSTRAINT [FK_ProductionTarget_ArrivalProductionTargetID] FOREIGN KEY([ArrivalProductionTargetID])
REFERENCES [dbo].[DictProductionTarget] ([ProductionTargetID])
GO
ALTER TABLE [dbo].[CattleDetailAdditional] CHECK CONSTRAINT [FK_ProductionTarget_ArrivalProductionTargetID]
GO
ALTER TABLE [dbo].[CattleDetailAdditional]  WITH CHECK ADD  CONSTRAINT [FK_ProductionTarget_RemovalProductionTargetID] FOREIGN KEY([RemovallProductionTargetID])
REFERENCES [dbo].[DictProductionTarget] ([ProductionTargetID])
GO
ALTER TABLE [dbo].[CattleDetailAdditional] CHECK CONSTRAINT [FK_ProductionTarget_RemovalProductionTargetID]
GO
ALTER TABLE [dbo].[CattleDetailAdditional]  WITH CHECK ADD  CONSTRAINT [FK_Transfer_ArrivalTransferID] FOREIGN KEY([ArrivalTransferID])
REFERENCES [dbo].[DictTransfer] ([TransferID])
GO
ALTER TABLE [dbo].[CattleDetailAdditional] CHECK CONSTRAINT [FK_Transfer_ArrivalTransferID]
GO
ALTER TABLE [dbo].[CattleDetailAdditional]  WITH CHECK ADD  CONSTRAINT [FK_Transfer_RemovalTransferID] FOREIGN KEY([RemovalTransferID])
REFERENCES [dbo].[DictTransfer] ([TransferID])
GO
ALTER TABLE [dbo].[CattleDetailAdditional] CHECK CONSTRAINT [FK_Transfer_RemovalTransferID]
GO
ALTER TABLE [dbo].[CattleDetailAdditional]  WITH CHECK ADD  CONSTRAINT [FK_Treatment_TreatmentID] FOREIGN KEY([TreatmentID])
REFERENCES [dbo].[Treatment] ([TreatmentID])
GO
ALTER TABLE [dbo].[CattleDetailAdditional] CHECK CONSTRAINT [FK_Treatment_TreatmentID]
GO
ALTER TABLE [dbo].[CattleDetailBasic]  WITH NOCHECK ADD  CONSTRAINT [FK_Breed_BreedID] FOREIGN KEY([BreedID])
REFERENCES [dbo].[DictBreed] ([BreedID])
GO
ALTER TABLE [dbo].[CattleDetailBasic] CHECK CONSTRAINT [FK_Breed_BreedID]
GO
ALTER TABLE [dbo].[CattleDetailBasic]  WITH NOCHECK ADD  CONSTRAINT [FK_Colour_ColourID] FOREIGN KEY([ColourID])
REFERENCES [dbo].[DictColour] ([ColourID])
GO
ALTER TABLE [dbo].[CattleDetailBasic] CHECK CONSTRAINT [FK_Colour_ColourID]
GO
ALTER TABLE [dbo].[CattleDetailBasic]  WITH NOCHECK ADD  CONSTRAINT [FK_DictCountryCode_CountryCodeID] FOREIGN KEY([HoldingCountryCodeID])
REFERENCES [dbo].[DictCountryCode] ([CountryCodeID])
GO
ALTER TABLE [dbo].[CattleDetailBasic] CHECK CONSTRAINT [FK_DictCountryCode_CountryCodeID]
GO
ALTER TABLE [dbo].[CattleDetailBasic]  WITH NOCHECK ADD  CONSTRAINT [FK_Sex_SexID] FOREIGN KEY([SexID])
REFERENCES [dbo].[DictSex] ([SexID])
GO
ALTER TABLE [dbo].[CattleDetailBasic] CHECK CONSTRAINT [FK_Sex_SexID]
GO
ALTER TABLE [dbo].[FarmDetail]  WITH NOCHECK ADD  CONSTRAINT [FK_DictCountryCode_DictCountryCodeID] FOREIGN KEY([CountryCodeID])
REFERENCES [dbo].[DictCountryCode] ([CountryCodeID])
GO
ALTER TABLE [dbo].[FarmDetail] CHECK CONSTRAINT [FK_DictCountryCode_DictCountryCodeID]
GO
ALTER TABLE [dbo].[Treatment]  WITH CHECK ADD  CONSTRAINT [FK_Medicine_MedicineID] FOREIGN KEY([MedicineID])
REFERENCES [dbo].[Medicine] ([MedicineID])
GO
ALTER TABLE [dbo].[Treatment] CHECK CONSTRAINT [FK_Medicine_MedicineID]
GO
ALTER TABLE [dbo].[UserLoginHistory]  WITH CHECK ADD  CONSTRAINT [FK_DictUser_UserID] FOREIGN KEY([UserLoginHistoryID])
REFERENCES [dbo].[DictUser] ([UserID])
GO
ALTER TABLE [dbo].[UserLoginHistory] CHECK CONSTRAINT [FK_DictUser_UserID]
GO
/****** Object:  StoredProcedure [dbo].[ImportCsv]    Script Date: 2021.08.21 17:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   PROC [dbo].[ImportCsv]
	@FilePath varchar(100) = NULL,
	@TargetTable varchar(100) = NULL,
	@CODEPAGE varchar(10) = 65001,
	@FIRSTROW varchar(10) = 2,
	@FIELDTERMINATOR varchar(5) = ';',
	@ROWTERMINATOR varchar(5) = '\n'
AS
BEGIN
	SET NOCOUNT ON

	IF  OBJECT_ID(@TargetTable, 'U') IS NOT NULL 
		BEGIN
		DECLARE @sql varchar(max)
		SET @sql = 'BULK INSERT '+ @TargetTable +' FROM ''' + @FilePath + ''' 
		WITH (
			CODEPAGE = '+@CODEPAGE + ', 
			FIRSTROW = ' + @FIRSTROW + ',  
			FIELDTERMINATOR = ''' + @FIELDTERMINATOR + ''', 
			ROWTERMINATOR = ''' + @ROWTERMINATOR + '''
		)'
		EXEC (@sql)
		END
	ELSE
		RETURN 1
	--Nincs ilyen tábla

END
GO
USE [master]
GO
ALTER DATABASE [HunlandCattleSystem] SET  READ_WRITE 
GO
