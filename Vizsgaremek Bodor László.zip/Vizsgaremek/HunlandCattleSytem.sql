﻿ -- Adatbázis létrehozása
DROP DATABASE IF EXISTS HunlandCattleSystem;
DROP TABLE IF EXISTS tempdb.dbo.DictUser
DROP TABLE IF EXISTS tempdb.dbo.UserLoginHistory
DROP Table IF EXISTS tempdb.dbo.DictCountryCode
DROP Table IF EXISTS tempdb.dbo.FarmDetail
DROP Table IF EXISTS tempdb.dbo.CattleDetailBasic
DROP Table IF EXISTS tempdb.dbo.CattleDetailBasic
DROP Table IF EXISTS tempdb.dbo.CattleDetailAdditional
DROP Table IF EXISTS tempdb.dbo.DictBreed
DROP Table IF EXISTS tempdb.dbo.DictSex
DROP Table IF EXISTS tempdb.dbo.DictColour
DROP Table IF EXISTS tempdb.dbo.DictClass
DROP Table IF EXISTS tempdb.dbo.DictTransfer
DROP Table IF EXISTS tempdb.dbo.DictProductionTarget
DROP Table IF EXISTS tempdb.dbo.Treatment
DROP Table IF EXISTS tempdb.dbo.Medicine
 
CREATE DATABASE HunlandCattleSystem ON  PRIMARY 
			( NAME = N'HunlandCattleSystem', FILENAME = N'e:\Traning360\Adatbázis specialista\Adatbázisok\HunlandCattleSystem.mdf' , SIZE = 112640KB , FILEGROWTH = 10%), 
		FILEGROUP TrainingData 
			( NAME = N'HunlandCattleSystemDataFile', FILENAME = N'e:\Traning360\Adatbázis specialista\Adatbázisok\HunlandCattleSystemDataFile.ndf' , SIZE = 112640KB , FILEGROWTH = 10%)
		LOG ON 
		( NAME = N'HunlandCattleSystem_log', FILENAME = N'e:\Traning360\Adatbázis specialista\Adatbázisok\HunlandCattleSystemDataFile_log.ldf' , SIZE = 8192KB , FILEGROWTH = 65536KB )
		COLLATE Hungarian_100_CI_AS 
-- Táblák feltöltése

USE HunlandCattleSystem
CREATE TABLE [DictUser] (
  [UserID] int IDENTITY(1, 1),
  [FirstName] varchar(20) NOT NULL,
  [MiddleName] varchar(20),
  [LastName] varchar(20) NOT NULL,
  [UserName] varchar(20) NOT NULL,
  [UserPassword] varchar(50) NOT NULL,
  [EmailAddress] varchar(50) NOT NULL,
  [AdminRole] bit NOT NULL,
  [MedicineRole] bit NOT NULL,
  [TreatmentRole] bit NOT NULL,
  [CatlleRole] bit NOT NULL,
  [IsActive] bit NOT NULL,
  [CurrentHoldingCodeID] int)
	ALTER TABLE dbo.DictUser
		ADD CONSTRAINT PK_DictUser_UserID PRIMARY KEY CLUSTERED (UserID)

CREATE TABLE [UserLoginHistory] (
  [UserLoginHistoryID] int IDENTITY(1, 1),
  [UserID] int NOT NULL,
  [IPaddress] varchar(50) NOT NULL,
  [SystemVersion] varchar(50) NOT NULL,
  [MacAddress] varchar(50) NOT NULL,
  [LoginDate] datetime2 NOT NULL,
  [LogoutDate] datetime2 NOT NULL)
  	ALTER TABLE dbo.UserLoginHistory
		ADD CONSTRAINT PK_UserLoginHistory_UserLoginHistoryID PRIMARY KEY CLUSTERED (UserLoginHistoryID)

CREATE TABLE [DictCountryCode] (
  [CountryCodeID] int IDENTITY(1, 1),
  [CountryCodeDetailE] varchar(50) NOT NULL,
  [CountryCodeDetailH] varchar(50) NOT NULL,
  [CountryCodeISO2] varchar(2) NOT NULL,
  [CountryCodeISO3] varchar(3) NOT NULL,
  [CountryCodeNumeric] smallint)
  	ALTER TABLE dbo.DictCountryCode
		ADD CONSTRAINT PK_DictCountryCode_CountryCodeID PRIMARY KEY CLUSTERED (CountryCodeID)

CREATE TABLE [FarmDetail] (
  [HoldingCodeID] int IDENTITY(1, 1),
  [CountryCodeID] int NOT NULL,
  [FarmDetailName] varchar(50) NOT NULL,
  [FarmDetailAddress] varchar(50) NOT NULL,
  [FarmDetailTown] varchar(30) NOT NULL,
  [FarmDetailPhone] varchar(50),
  [FarmDetailHoldingCode] varchar(30),
  [FarmDetailActive] bit NOT NULL,
  [FarmDetailIsPartner] bit NOT NULL)
  	ALTER TABLE dbo.FarmDetail
		ADD CONSTRAINT PK_FarmDetail_HoldingCodeID PRIMARY KEY CLUSTERED (HoldingCodeID)

CREATE TABLE [CattleDetailBasic] (
  [CattleDetailID] int IDENTITY(1, 1),
  [WorkNumber] varchar(6) NOT NULL,
  [CattleCountryCodeID] int NOT NULL,
  [IdentificationNumber] varchar(25),
  [ExportNumber] tinyint,
  [SexID] tinyint NOT NULL,
  [BreedID] tinyint NOT NULL,
  [ColourID] tinyint NOT NULL,
  [DateOfBirth] smalldatetime NOT NULL,
  [DamsCountryCodeID] int NOT NULL,
  [DamsNumber] varchar(25) NOT NULL,
  [HoldingCountryCodeID] int NOT NULL,
  [HoldingCodeID] int NOT NULL)
  	ALTER TABLE dbo.CattleDetailBasic
		ADD CONSTRAINT PK_CattleDetailBasic_CattleDetailID PRIMARY KEY CLUSTERED (CattleDetailID)

CREATE TABLE [CattleDetailAdditional] (
  [DetailEventID] int IDENTITY(1, 1),
  [CattleDetailID] int NOT NULL,
  [CurrentHoldingCodeID] int NOT NULL,
  [StableNumber] smallint,
  [ArrivalWeight] smallint NOT NULL,
  [RemovalWeight] smallint,
  [Weighing] smallint,
  [ArrivalClassID] tinyint NOT NULL,
  [RemovalClassID] tinyint,
  [DateOfArrival] smalldatetime NOT NULL,
  [DateOfRemoval] smalldatetime,
  [ArrivalTransferID] tinyint NOT NULL,
  [RemovalTransferID] tinyint,
  [ArrivalProductionTargetID] tinyint NOT NULL,
  [RemovallProductionTargetID] tinyint,
  [ArrivalLicensePlateTruck] varchar(10) NOT NULL,
  [ArrivalLicensePlateTrailer] varchar(10) NOT NULL,
  [RemovalLicensePlateTruck] varchar(10),
  [RemovalLicensePlateTrailer] varchar(10),
  [PrchasePrice] money,
  [SellingPrice] money,
  [TreatmentID] int)
  	ALTER TABLE dbo.CattleDetailAdditional
		ADD CONSTRAINT PK_CattleDetailAdditional_DetailEventID PRIMARY KEY CLUSTERED (DetailEventID)

CREATE TABLE [DictBreed] (
  [BreedID] tinyint IDENTITY(1, 1),
  [BreedCode] varchar(3) NOT NULL,
  [BreedE] varchar(80) NOT NULL,
  [BreedH] varchar(80) NOT NULL,
  [BreedActive] bit NOT NULL)
  	ALTER TABLE dbo.DictBreed
		ADD CONSTRAINT PK_DictBreed_BreedID PRIMARY KEY CLUSTERED (BreedID)


CREATE TABLE [DictSex] (
  [SexID] tinyint IDENTITY(1, 1),
  [SexOrgCodeE] varchar(2) NOT NULL,
  [SexOrgCodeH] varchar(2) NOT NULL,
  [SexE] varchar(25) NOT NULL,
  [SexH] varchar(25) NOT NULL)
  	ALTER TABLE dbo.DictSex
		ADD CONSTRAINT PK_DictSex_SexID PRIMARY KEY CLUSTERED (SexID)

CREATE TABLE [DictColour] (
  [ColourID] tinyint IDENTITY(1, 1),
  [ColourCodeE] varchar(3),
  [ColourCodeH] varchar(3) NOT NULL,
  [ColourDetailH] varchar(30) NOT NULL,
  [ColourDetailE] varchar(30),
  [ColourActive] bit NOT NULL)
  	ALTER TABLE dbo.DictColour
		ADD CONSTRAINT PK_DictColour_ColourID PRIMARY KEY CLUSTERED (ColourID)

CREATE TABLE [DictClass] (
  [ClassID] tinyint IDENTITY(1, 1),
  [ClassCode] varchar(5) NOT NULL,
  [ClassDetailE] varchar(30) NOT NULL,
  [ClassDetailH] varchar(30) NOT NULL,
  [ClassActive] bit NOT NULL)
  	ALTER TABLE dbo.DictClass
		ADD CONSTRAINT PK_DictClass_ClassID PRIMARY KEY CLUSTERED (ClassID)

CREATE TABLE [DictTransfer] (
  [TransferID] tinyint IDENTITY(1, 1),
  [TransferCode] varchar(2) NOT NULL,
  [TransferDetailE] varchar(30) NOT NULL,
  [TransferDetailH] varchar(30) NOT NULL,
  [TransferActive] bit NOT NULL)
  	ALTER TABLE dbo.DictTransfer
		ADD CONSTRAINT PK_DictTransfer_TransferID PRIMARY KEY CLUSTERED (TransferID)

CREATE TABLE [DictProductionTarget] (
  [ProductionTargetID] tinyint IDENTITY(1, 1),
  [ProductionTargetCodeE] varchar(2) NOT NULL,
  [ProductionTargetCode] varchar(2) NOT NULL,
  [ProductionTargetDetailE] varchar(30) NOT NULL,
  [ProductionTargetDetailH] varchar(30) NOT NULL)
  	ALTER TABLE dbo.DictProductionTarget
		ADD CONSTRAINT PK_DictProductionTarget_ProductionTargetID PRIMARY KEY CLUSTERED (ProductionTargetID)

CREATE TABLE [Treatment] (
  [TreatmentID] int IDENTITY(1, 1),
  [CatlleDetailID] int NOT NULL,
  [HoldingCode] varchar(30) NOT NULL,
  [DateOfTreatment] smalldatetime NOT NULL,
  [StableNumber] smallint,
  [DiagnosisName] varchar(50),
  [MedicineID] smallint,
  [Quantity] tinyint NOT NULL)  	
  ALTER TABLE dbo.Treatment
		ADD CONSTRAINT PK_Treatment_TreatmentID PRIMARY KEY CLUSTERED (TreatmentID)

CREATE TABLE [Medicine] (
  [MedicineID] smallint IDENTITY(1, 1) NOT NULL,
  [MedicineName] varchar(50),
  [MedicineQuantityUnit] smallint NOT NULL,
  [MedicineArticleNumber] varchar(25) NOT NULL,
  [MedicineCodeNumber] varchar(15))
  ALTER TABLE dbo.Medicine
		ADD CONSTRAINT PK_Medicine_MedicineID PRIMARY KEY CLUSTERED (MedicineID)

USE HunlandCattleSystem
-- idegen kulcsok
ALTER TABLE  dbo.CattleDetailBasic ADD CONSTRAINT FK_Breed_BreedID FOREIGN KEY ([BreedID]) REFERENCES [DictBreed] ([BreedID])
ALTER TABLE dbo.CattleDetailBasic ADD CONSTRAINT FK_Colour_ColourID FOREIGN KEY ([ColourID]) REFERENCES [DictColour] ([ColourID])
ALTER TABLE dbo.CattleDetailBasic ADD CONSTRAINT FK_Sex_SexID FOREIGN KEY ([SexID]) REFERENCES [DictSex] ([SexID])
ALTER TABLE dbo.CattleDetailAdditional ADD CONSTRAINT FK_Transfer_ArrivalTransferID FOREIGN KEY ([ArrivalTransferID]) REFERENCES [DictTransfer] ([TransferID])
ALTER TABLE dbo.CattleDetailAdditional  ADD CONSTRAINT FK_Transfer_RemovalTransferID FOREIGN KEY ([RemovalTransferID]) REFERENCES [DictTransfer] ([TransferID])
ALTER TABLE dbo.CattleDetailAdditional  ADD CONSTRAINT FK_Class_ArrivalClassID FOREIGN KEY ([ArrivalClassID]) REFERENCES [DictClass] ([ClassID])
ALTER TABLE dbo.CattleDetailAdditional  ADD CONSTRAINT FK_Class_RemovalClassID FOREIGN KEY ([RemovalClassID]) REFERENCES [DictClass] ([ClassID])
ALTER TABLE dbo.CattleDetailAdditional  ADD CONSTRAINT FK_ProductionTarget_ArrivalProductionTargetID FOREIGN KEY ([ArrivalProductionTargetID]) REFERENCES [DictProductionTarget] ([ProductionTargetID])
ALTER TABLE dbo.CattleDetailAdditional  ADD CONSTRAINT FK_ProductionTarget_RemovalProductionTargetID FOREIGN KEY ([RemovallProductionTargetID]) REFERENCES [DictProductionTarget] ([ProductionTargetID])
ALTER TABLE dbo.FarmDetail ADD CONSTRAINT FK_DictCountryCode_DictCountryCodeID FOREIGN KEY ([CountryCodeID]) REFERENCES [DictCountryCode] ([CountryCodeID])
ALTER TABLE dbo.CattleDetailBasic ADD CONSTRAINT FK_DictCountryCode_CountryCodeID FOREIGN KEY ([HoldingCountryCodeID]) REFERENCES [DictCountryCode] ([CountryCodeID])
ALTER TABLE dbo.CattleDetailAdditional  ADD CONSTRAINT FK_FarmDetail_HoldingCodeID FOREIGN KEY ([CurrentHoldingCodeID]) REFERENCES [FarmDetail] ([HoldingCodeID])
ALTER TABLE dbo.CattleDetailAdditional ADD CONSTRAINT FK_Treatment_TreatmentID FOREIGN KEY ([TreatmentID]) REFERENCES [Treatment] ([TreatmentID])
ALTER TABLE dbo.CattleDetailAdditional ADD CONSTRAINT FK_CattleDetailBasic_CattleDetailID FOREIGN KEY ([CattleDetailID]) REFERENCES [CattleDetailBasic] ([CattleDetailID])
ALTER TABLE dbo.UserLoginHistory ADD CONSTRAINT FK_DictUser_UserID  FOREIGN KEY ([UserLoginHistoryID]) REFERENCES [DictUser] ([UserID])
ALTER TABLE dbo.Treatment ADD CONSTRAINT FK_Medicine_MedicineID FOREIGN KEY ([MedicineID]) REFERENCES [Medicine] ([MedicineID])

GO
CREATE OR ALTER PROC ImportCsv
	@FilePath varchar(100) = NULL,
	@TargetTable varchar(100) = NULL,
	@CODEPAGE varchar(10) = 65001,
	@FIRSTROW varchar(10) = 2,
	@FIELDTERMINATOR varchar(5) = ';',
	@ROWTERMINATOR varchar(5) = '\n'
AS
BEGIN
	SET NOCOUNT ON

	IF  OBJECT_ID(@TargetTable, 'U') IS NOT NULL 
		BEGIN
		DECLARE @sql varchar(max)
		SET @sql = 'BULK INSERT '+ @TargetTable +' FROM ''' + @FilePath + ''' 
		WITH (
			CODEPAGE = '+@CODEPAGE + ', 
			FIRSTROW = ' + @FIRSTROW + ',  
			FIELDTERMINATOR = ''' + @FIELDTERMINATOR + ''', 
			ROWTERMINATOR = ''' + @ROWTERMINATOR + '''
		)'
		EXEC (@sql)
		END
	ELSE
		RETURN 1
	--Nincs ilyen tábla

END
GO
--Alapadatok beolvasása .CSV-ből
EXEC ImportCsv 'e:\Traning360\Adatbázis specialista\Vizsgaremek\CSV\FarmDetail.csv', FarmDetail, 65001,1
EXEC ImportCsv 'e:\Traning360\Adatbázis specialista\Vizsgaremek\CSV\CountryCode.csv', DictCountryCode, 65001,1
EXEC ImportCsv 'e:\Traning360\Adatbázis specialista\Vizsgaremek\CSV\ProductionTarget.csv', DictProductionTarget, 65001,1
EXEC ImportCsv 'e:\Traning360\Adatbázis specialista\Vizsgaremek\CSV\Transfer.csv', DictTransfer, 65001,1
EXEC ImportCsv 'e:\Traning360\Adatbázis specialista\Vizsgaremek\CSV\Class.csv', DictClass, 65001,1
EXEC ImportCsv 'e:\Traning360\Adatbázis specialista\Vizsgaremek\CSV\Colour.csv', DictColour, 65001,1
EXEC ImportCsv 'e:\Traning360\Adatbázis specialista\Vizsgaremek\CSV\Sex.csv', DictSex, 65001,1
EXEC ImportCsv 'e:\Traning360\Adatbázis specialista\Vizsgaremek\CSV\Breed.csv', DictBreed, 65001,1
EXEC ImportCsv 'e:\Traning360\Adatbázis specialista\Vizsgaremek\CSV\CattleDetailBasic.csv', CattleDetailBasic, 65001,1


 --Users and Login
USE [HunlandCattleSystem]
CREATE ROLE [HunStock]
use [HunlandCattleSystem]
GRANT INSERT ON [dbo].[CattleDetailAdditional] TO [HunStock]
use [HunlandCattleSystem]
GRANT SELECT ON [dbo].[CattleDetailBasic] TO [HunStock]
use [HunlandCattleSystem]
GRANT EXECUTE ON [dbo].[DictBreed] TO [HunStock]
use [HunlandCattleSystem]
GRANT SELECT ON [dbo].[DictClass] TO [HunStock]
USE [HunlandCattleSystem]
CREATE ROLE [HunMember]
use [HunlandCattleSystem]
GRANT SELECT ON [dbo].[DictColour] TO [HunMember]
USE [HunlandCattleSystem]
CREATE ROLE [Hunadmin]
use [HunlandCattleSystem]
GRANT EXECUTE ON [dbo].[DictCountryCode] TO [Hunadmin]
use [HunlandCattleSystem]
GRANT CONTROL ON [dbo].[DictProductionTarget] TO [Hunadmin]
use [HunlandCattleSystem]
GRANT EXECUTE ON [dbo].[DictSex] TO [Hunadmin]
use [HunlandCattleSystem]
GRANT EXECUTE ON [dbo].[DictTransfer] TO [Hunadmin]
use [HunlandCattleSystem]
GRANT SELECT ON [dbo].[DictUser] TO [Hunadmin]
use [HunlandCattleSystem]
GRANT SELECT ON [dbo].[FarmDetail] TO [Hunadmin]
use [HunlandCattleSystem]
GRANT SELECT ON [dbo].[Medicine] TO [Hunadmin]
USE [master]
CREATE LOGIN [HunStock] WITH PASSWORD=N'' MUST_CHANGE, DEFAULT_DATABASE=[master], CHECK_EXPIRATION=ON, CHECK_POLICY=ON
USE [HunlandCattleSystem]
CREATE USER [HunStock] FOR LOGIN [HunStock]
USE [HunlandCattleSystem]
ALTER ROLE [HunStock] ADD MEMBER [HunStock]
USE [master]
CREATE LOGIN [HunMember] WITH PASSWORD=N'' MUST_CHANGE, DEFAULT_DATABASE=[master], CHECK_EXPIRATION=ON, CHECK_POLICY=ON
USE [HunlandCattleSystem]
CREATE USER [HunMember] FOR LOGIN [HunMember]
USE [HunlandCattleSystem]
ALTER ROLE [HunMember] ADD MEMBER [HunMember]
USE [master]
CREATE LOGIN [HunAdmin] WITH PASSWORD=N'' MUST_CHANGE, DEFAULT_DATABASE=[master], CHECK_EXPIRATION=ON, CHECK_POLICY=ON
USE [HunlandCattleSystem]
CREATE USER [HunAdmin] FOR LOGIN [HunAdmin]
USE [HunlandCattleSystem]
ALTER ROLE [Hunadmin] ADD MEMBER [HunAdmin]
USE [HunlandCattleSystem]
CREATE APPLICATION ROLE [RRApp] WITH PASSWORD = N'password'
use [HunlandCattleSystem]
GRANT INSERT ON [dbo].[ApplicationInReadingRoom] TO [RRApp]
use [HunlandCattleSystem]
GRANT SELECT ON [dbo].[ApplicationInReadingRoom] TO [RRApp]
USE [HunlandCattleSystem]
CREATE APPLICATION ROLE [TabletApp] WITH PASSWORD = N'password'
use [HunlandCattleSystem]
GRANT DELETE ON [dbo].[TabletApp] TO [TabletApp]
use [HunlandCattleSystem]
GRANT INSERT ON [dbo].[TabletApp] TO [TabletApp]
use [HunlandCattleSystem]
GRANT SELECT ON [dbo].[TabletApp] TO [TabletApp]

GO
CREATE OR ALTER PROC InsertUser
	@UserName varchar(20) = NULL,
	@UserID int = NULL,
	@UserPassword varchar(50) = NULL,
	@IsAdmin bit
AS
BEGIN
	SET NOCOUNT ON

	IF EXISTS (SELECT * FROM dbo.[dictUser] U WHERE U.UserID = @UserID )
		RETURN 1
		-- Egy Partnerhez csak egy regisztráció tartozhat

	ELSE IF EXISTS (SELECT * FROM dbo.[dictUser] U WHERE U.UserName = @UserName )
		RETURN 2
		-- Foglalt felhasználónév
	
	ELSE IF LEN(@UserName) < 3 OR LEN(@UserPassword) < 8
		RETURN 3
	
	ELSE
	DECLARE @salt varchar(5)
	SET @salt = LEFT( CAST (HASHBYTES ('SHA2_512',@UserName) as varchar),10)

	DECLARE @PassWithSalt varchar(100)
	SET @PassWithSalt = @UserPassword + @salt

	DECLARE @HasdPass varchar(100)
	SET @HasdPass = HASHBYTES('SHA2_512', @PassWithSalt)

	INSERT dbo.[dictUser] (UserName, UserID, UserPasswordHash,UserPasswordSalt, IsAdmin)
	VALUES (@UserName,@UserID, @HasdPass,@salt,@IsAdmin)

END
GO

--Backup
USE [msdb]
GO
DECLARE @jobId BINARY(16)
EXEC  msdb.dbo.sp_add_job @job_name=N'Backup-HunlandCattleSystem', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_page=2, 
		@delete_level=0, 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DESKTOP-6IG5VE6\tothl', @job_id = @jobId OUTPUT
select @jobId
GO
EXEC msdb.dbo.sp_add_jobserver @job_name=N'Backup-HunlandCattleSystem', @server_name = N'BodorSoft'
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_add_jobstep @job_name=N'Backup-HunlandCattleSystem', @step_name=N'1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_fail_action=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'BACKUP DATABASE [HunlandCattleSystem] TO  DISK = N''e:\Traning360\Adatbázis specialista\Vizsgaremek\Backup\HunlandCattleSystem.bak'' WITH NOFORMAT, NOINIT,  NAME = N''HunlandCattleSystem-Full Database Backup'', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO
', 
		@database_name=N'master', 
		@flags=0
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_update_job @job_name=N'Backup-HunlandCattleSystem', 
		@enabled=1, 
		@start_step_id=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_page=2, 
		@delete_level=0, 
		@description=N'', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'BodorSoft\Laci', 
		@notify_email_operator_name=N'', 
		@notify_page_operator_name=N''
GO
USE [msdb]
GO
DECLARE @schedule_id int
EXEC msdb.dbo.sp_add_jobschedule @job_name=N'Backup-HunlandCattleSystem', @name=N'dailybackup', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20210816, 
		@active_end_date=99991231, 
		@active_start_time=220000, 
		@active_end_time=235959, @schedule_id = @schedule_id OUTPUT
select @schedule_id
GO


CREATE UNIQUE NONCLUSTERED INDEX AK_FlightSeat_BookingID ON dbo.CattleDetailBasic(CattleDetailBasicID)
		WHERE CattleDetailBasicID IS NOT NULL
CREATE UNIQUE NONCLUSTERED INDEX AK_Aircraft_AirlineCode ON dbo.CattleDetailAdditional (DetailEventID)
		WHERE DetailEventID IS NOT NULL
CREATE UNIQUE NONCLUSTERED INDEX AK_DictEventType_EventTypeCode ON dbo.FarmDetail (HoldingCodeID)
		WHERE HoldingCodeID IS NOT NULL
CREATE UNIQUE NONCLUSTERED INDEX AK_Checkpoint_CheckpointCode ON dbo.[Treatment] (TreatmentID)
		WHERE TreatmentID IS NOT NULL